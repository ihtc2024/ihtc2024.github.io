from ihhospital import *
import copy
import numpy as np
import math

class IHGenerator:
  def __init__(self):
    self.days = -1
    self.patients_density = -1
    self.num_surgeons = -1
    self.num_operating_theaters = -1
    self.num_rooms = -1
    self.num_nurses = -1  #only used internally in the generator
    self.num_occupants = -1
    self.mandatory_ratio = -1
    self.skills = -1
    self.age_groups = -1
    self.hospital_data = HospitalData()
    
  def get_num_patients(self):
      return math.ceil(self.hospital_data.days*self.patients_density)
  @staticmethod
  def random_weeks():
    return random.randint(2, 4)
  def set_parameter(self, parameter, value):
    if parameter == "patients_density":
      self.patients_density = value
    elif parameter == "surgeons":
      self.num_surgeons = value
    elif parameter == "operating_theaters":
      self.num_operating_theaters = value
    elif parameter == "rooms":
      self.num_rooms = value
    elif parameter == "occupants":
      self.num_occupants = value
    elif parameter == "skills":
      if value < 2 or value > 5:
        raise ValueError("skills must be between 2 and 5")
      self.skills = value
    elif parameter == "age_groups":
      if value < 2 or value > 5:
        raise ValueError("age_groups must be between 2 and 5")
      self.age_groups = value
    elif parameter == "mandatory_ratio":
      if value < 0.0 or value > 0.999:
        raise ValueError("Mandatory ratio must be between 0 and 0.999")
      self.mandatory_ratio = value
    elif parameter == "scheduling_horizon":
      if value%7 != 0:
        raise ValueError("Scheduling horizon must be a multiple of 7")
      self.days = value
  
  def generate_random_data(self):
    if self.days == -1:
      self.days = random.choice(self.hospital_data.configuration["scheduling_horizons"])
    self.hospital_data.set_scheduling_horizon(self.days)
    if self.patients_density == -1:
      self.patients_density = random.randint(1, 50) 
    if self.mandatory_ratio != -1:
      self.hospital_data.configuration["mandatory_ratio"] = self.mandatory_ratio
    if self.num_surgeons == -1:
      self.num_surgeons = random.randint(math.ceil(self.patients_density/5), math.ceil(self.patients_density/2))
    if self.num_operating_theaters == -1:
      self.num_operating_theaters  = random.randint(math.ceil(self.num_surgeons*0.5)+1, math.ceil(self.num_surgeons*1.5))
    if self.skills == -1:
       self.skills = random.randint(2, 5)
    if self.age_groups == -1:
       self.age_groups = random.randint(2, 5)
    #in order to estimate the number of beds needed, we first estimate the average hospital occupancy, as the weighted mean of the stay durations
    expected_nights_per_patient = sum(key * value for key, value in self.hospital_data.configuration["lengths_of_stay"].items()) / sum(self.hospital_data.configuration["lengths_of_stay"].values())
    #then, the average expected occupacy is given by the patient density times the expected nights per patient
    expected_occupacy = self.patients_density * expected_nights_per_patient
    #finally, the number of rooms is set as the expected occupancy divided by the average size of the rooms
    if self.num_rooms == -1:
      self.num_rooms = random.randint(math.ceil(expected_occupacy/max(self.hospital_data.configuration["room_size"])), math.ceil(expected_occupacy/min(self.hospital_data.configuration["room_size"])))

    #I set skill levels and age groups
    self.hospital_data.set_age_groups(self.age_groups)
    self.hospital_data.configuration["skill_levels"] = self.skills
    
    #ROOMS
    for i in range(self.num_rooms):
      room = Room(
        room_id= "r" + id_to_string(i,self.num_rooms-1),
        capacity=random.choice(self.hospital_data.configuration["room_size"])
      )
      self.hospital_data.rooms.append(room)

    room_occupancy = [0 for _ in range(self.num_rooms)]
    room_gender = [None for _ in range(self.num_rooms)]
    
    total_cap=sum(self.hospital_data.rooms[i].capacity for i in range(self.num_rooms))
    self.num_occupants=round(random.uniform(self.hospital_data.configuration["occupants_min_max"][0], self.hospital_data.configuration["occupants_min_max"][1])*total_cap)
    for _ in range(self.num_occupants):
      occupant = Occupant()
      feasible_occupant = False
      while not feasible_occupant:
        feasible_occupant = True
        occupant.RandomOccupant(len(self.hospital_data.occupants),self.num_occupants,self.num_rooms,self.hospital_data.configuration)
        if(room_occupancy[id_to_int(occupant.room_id)]==0):
          room_occupancy[id_to_int(occupant.room_id)]+=1
          room_gender[id_to_int(occupant.room_id)]=occupant.gender
        elif(room_occupancy[id_to_int(occupant.room_id)]<self.hospital_data.rooms[id_to_int(occupant.room_id)].capacity and occupant.gender==room_gender[id_to_int(occupant.room_id)]):
          room_occupancy[id_to_int(occupant.room_id)]+=1
        else:
          feasible_occupant=False
      self.hospital_data.occupants.append(occupant)

    #SURGEONS
    for i in range(self.num_surgeons):
      surgeon = Surgeon()
      surgeon.RandomSurgeon(i,self.num_surgeons,self.hospital_data.days)
      self.hospital_data.surgeons.append(surgeon)

    #operating_theaters
    for i in range(self.num_operating_theaters):
      operating_room = OperatingTheater()
      operating_room.RandomOperatingTheater(i,self.num_operating_theaters,self.hospital_data.days)
      self.hospital_data.operating_theaters.append(operating_room)
    
    #PATIENTS
    # We copy the surgeon vector, to monitor the residual surgeon load parameter
    residual_surgeon_load = copy.deepcopy(self.hospital_data.surgeons)
    residual_theaters_load = [0 for _ in range(self.hospital_data.days)]
    for d in range(self.hospital_data.days):
      for i in range(len(self.hospital_data.operating_theaters)):
        residual_theaters_load[d] += self.hospital_data.operating_theaters[i].availability[d]

    # generate the patient
    for _ in range(self.get_num_patients()):
      patient = Patient()
      feasible_patient = False
      while not feasible_patient:
        feasible_patient = True
        patient.RandomPatient(len(self.hospital_data.patients),self.hospital_data.days,self.num_surgeons,self.get_num_patients(),self.hospital_data.configuration,self.hospital_data.surgeons)
        
        # I check that there is enough surgeon and OT capacity on the release day, to ensure that the patient can be admitted. 
        # For mandatory patients, I also check the same condition on the due day.
        # For non mandatory patients, there is a slight probability that the generated patient cannot be admitted in practice, to increase the variability of the instances.
        if residual_surgeon_load[id_to_int(patient.surgeon_id)].max_surgery_time[patient.surgery_release_day] - patient.surgery_duration < 0 or residual_theaters_load[patient.surgery_release_day] - patient.surgery_duration < 0 or (patient.mandatory and (residual_surgeon_load[id_to_int(patient.surgeon_id)].max_surgery_time[patient.surgery_due_day] - patient.surgery_duration < 0 or residual_theaters_load[patient.surgery_due_day] - patient.surgery_duration < 0)):
          if patient.mandatory:
            feasible_patient = False
          else:
            if random.random() < 0.9: # if the patient is not mandatory, and and the designed surgeon does not enough capacity on his/her release day, we try to generate another patient.
              feasible_patient = False
            else: #  else we keep that patient, even if there is the possibilty that no feasible schedule can be found for it.
              this_theater_availability = 0
              for i in range(len(self.hospital_data.operating_theaters)):
                this_theater_availability += self.hospital_data.operating_theaters[i].availability[patient.surgery_release_day]
              if self.hospital_data.surgeons[id_to_int(patient.surgeon_id)].max_surgery_time[patient.surgery_release_day] - patient.surgery_duration < 0 or this_theater_availability - patient.surgery_duration < 0:
                feasible_patient = False 
        else:
          if patient.mandatory:
            #mandatory patients reduce the residual surgeon and theater capacity, so the following patients are generated accordingly to the reduced capacity, to ensure that mandatory patients can be actually scheduled.
            residual_surgeon_load[id_to_int(patient.surgeon_id)].max_surgery_time[patient.surgery_release_day] -= patient.surgery_duration
            residual_theaters_load[patient.surgery_release_day] -= patient.surgery_duration
      self.hospital_data.patients.append(patient)
   
    #NURSES
    self.num_nurses = 0

    #I estimate the total coverage required by the nurses, according to the number of rooms I have, unless the coverage required by the mandatory patients is higher, in that case I use the coverage by mandatory patients.
    remaining_shift_coverage = [np.average(self.hospital_data.configuration["workload_produced_minmax"]["night"])*np.average(self.hospital_data.configuration["room_size"])*self.num_rooms if (k+1)%self.hospital_data.configuration["shifts_per_day"] == 0 else np.average(self.hospital_data.configuration["workload_produced_minmax"]["day"])*np.average(self.hospital_data.configuration["room_size"])*self.num_rooms for k in range(self.hospital_data.days*self.hospital_data.configuration["shifts_per_day"])]

    while(sum(remaining_shift_coverage) > 0):
      unuseful_nurse = True  #I don't want to generate nurses at random that only cover shifts already covered by other nurses
      while unuseful_nurse: 
        nurse = Nurse()
        nurse.RandomNurse(self.num_nurses,self.hospital_data.days,self.get_num_patients(),self.hospital_data.configuration,remaining_shift_coverage)
        for s in range(len(nurse.working_shifts)):
          shift_value = self.hospital_data.get_shift_value(nurse.working_shifts[s])  
          if remaining_shift_coverage[shift_value] > 0:
            unuseful_nurse = False #if the nurse covers at least a shift that was not fully covered, it's useful
            break
        
      self.hospital_data.nurses.append(nurse)
      self.num_nurses = self.num_nurses+1
      #only used interally in the generator
      for s in range(len(nurse.working_shifts)):    
        shift_value = self.hospital_data.get_shift_value(nurse.working_shifts[s])  
        remaining_shift_coverage[shift_value] = max(0,remaining_shift_coverage[shift_value]-nurse.working_shifts[s]["max_load"])
        
    #patient to room incompatibilities
    for i in range(self.get_num_patients()):
      for j in range(self.num_rooms):
        if random.random() < 0.1:
          self.hospital_data.patients[i].incompatible_room_ids.append(self.hospital_data.rooms[j].id)
        
    instance = self.hospital_data.to_dict()
    #I add the weights
    instance["weights"] = {}
    instance["weights"]["room_mixed_age"]           = max(1,random.randint(0, 1)*5)
    instance["weights"]["room_nurse_skill"]         = max(1,random.randint(0, 2)*5) 
    instance["weights"]["continuity_of_care"]       = max(1,random.randint(0, 1)*5)
    instance["weights"]["nurse_eccessive_workload"] = max(1,random.randint(0, 2)*5) 
    instance["weights"]["open_operating_theater"]   = random.randint(1, 5)*10
    instance["weights"]["surgeon_transfer"]          = max(1,random.randint(0, 2)*5)
    instance["weights"]["patient_delay"]            = random.randint(1, 3)*5
    instance["weights"]["unscheduled_optional"]     = random.randint(3, 10)*50

    return instance
