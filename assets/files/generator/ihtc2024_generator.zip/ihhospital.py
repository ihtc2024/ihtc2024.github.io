import random
import json
import statistics

def id_to_string(this_id,max_id):
  this_id_str = ""
  digits = len(str(this_id))
  for i in range(len(str(max_id)) - digits):
    this_id_str = this_id_str + "0"
  this_id_str = this_id_str + str(this_id)
  return this_id_str

def id_to_int(this_id):
  #split the id from the first character
  return int(this_id[1:])

class Room:
  def __init__(self, room_id = None, capacity = None):
    self.id = room_id
    self.capacity = capacity

class Patient:
  def __init__(self, patient_id = None, mandatory = None, gender = None, age_group = None, length_of_stay = None, surgery_release_day = None, surgery_due_day = None, surgery_duration = None, surgeon_id = None, incompatible_room_ids=None,
         workload_produced=None, skill_level_required=None):
    self.id = patient_id
    self.mandatory = mandatory
    self.gender = gender
    self.age_group = age_group
    self.length_of_stay = length_of_stay
    self.surgery_release_day = surgery_release_day
    self.surgery_due_day = surgery_due_day
    self.surgery_duration = surgery_duration
    self.surgeon_id = surgeon_id
    self.incompatible_room_ids = incompatible_room_ids or []
    self.workload_produced = workload_produced or []
    self.skill_level_required = skill_level_required or []
    
  def RandomAge(self, hospital_configuration):
    age = -1
    while age > 100 or age < 0:
      if self.gender == "B":   
        age= 100 - int(random.lognormvariate(3.1,1.6))
      else:
        age= 100 - int(random.lognormvariate(2.8,1.3))
    for group in hospital_configuration["age_groups"].keys():
      if age >= hospital_configuration["age_groups"][group][0] and age <= hospital_configuration["age_groups"][group][1]:
        self.age_group = group

  def Adjust_los(self,configuration,duration):
    los_offset={60: -4, 90: -2, 120: 0, 180: 1, 240: 2, 300: 3}
    k=los_offset[duration]
    adj_lengths_of_stay={}
    for i, (key, value) in enumerate(configuration["lengths_of_stay"].items()):
      if k > 0 and i < k:
          adj_lengths_of_stay[key] = 0
      elif k < 0 and len(configuration["lengths_of_stay"]) + k <= i:
          adj_lengths_of_stay[key] = 0
      else:
        adj_lengths_of_stay[key] = value
    return adj_lengths_of_stay

  def RandomPatient(self,id,hospital_days,num_surgeons,num_patients,hospital_configuration,surg_vect):
    self.id = "p" + id_to_string(id,num_patients-1)
    self.mandatory = random.choices([True, False],weights=[hospital_configuration["mandatory_ratio"],1.0-hospital_configuration["mandatory_ratio"]])[0]
    self.gender=random.choice(["B", "A"])
    self.RandomAge(hospital_configuration)
    s=random.randint(0, num_surgeons-1)
    self.surgeon_id = "s" + id_to_string(s,num_surgeons-1)
    self.surgery_duration = random.choices([60, 90, 120, 180, 240, 300],weights=surg_vect[s].profile)[0]
    adjusted_lengths_of_stay=self.Adjust_los(hospital_configuration,self.surgery_duration)
    self.length_of_stay=random.choices(list(adjusted_lengths_of_stay.keys()), weights=list(adjusted_lengths_of_stay.values()), k=1)[0]
    self.surgery_release_day= -1
    try_again = True
    while try_again or self.surgery_release_day < 0 or self.surgery_release_day > hospital_days - 1:
      self.surgery_release_day = int(random.lognormvariate(hospital_configuration["lognormariate_releasedate"][0],hospital_configuration["lognormariate_releasedate"][1]))
      try_again = False
      #I want to have less probability that the "release date is on friday, saturday or sunday"
      if self.surgery_release_day%5 == 0 or self.surgery_release_day%6 == 0:
        try_again = random.random() < 0.5
      elif self.surgery_release_day%4 == 0:
        try_again = random.random() < 0.3
      if self.length_of_stay != hospital_days and self.surgery_release_day > hospital_days - 1 - self.length_of_stay:
        try_again = random.random() < 0.8
    self.surgery_due_day = -1

    if self.mandatory:
      while self.surgery_due_day < self.surgery_release_day:
        self.surgery_due_day = hospital_days - 1 - int(random.lognormvariate(hospital_configuration["lognormariate_releasedate"][0],hospital_configuration["lognormariate_releasedate"][1]))# - self.length_of_stay
    else:
      self.surgery_due_day = None
    self.workload_produced = [random.randint(hospital_configuration["workload_produced_minmax"]["night"][0], hospital_configuration["workload_produced_minmax"]["night"][1]) if (k+1)%hospital_configuration["shifts_per_day"] == 0 else random.randint(hospital_configuration["workload_produced_minmax"]["day"][0], hospital_configuration["workload_produced_minmax"]["day"][1]) for k in range(hospital_configuration["shifts_per_day"] * self.length_of_stay)]
    
    next_shifts = hospital_configuration["shifts_per_day"]*2
    k = len(self.workload_produced)-next_shifts
    while(k >= 0):
      if (k+1)%hospital_configuration["shifts_per_day"] != 0:
        #If it is much lower than the P next shifts, I increase it
        up_to_next_shift = min(k+next_shifts,len(self.workload_produced))
        if self.workload_produced[k] < statistics.mean(self.workload_produced[k+1:up_to_next_shift])-0.5:
          self.workload_produced[k] = self.workload_produced[k] + 1
      k -= 1
    
    self.skill_level_required=[random.randint(0, hospital_configuration["skill_levels"] - 1) for _ 
    in range(hospital_configuration["shifts_per_day"] * self.length_of_stay)]
    #I reduce the required skill at night
    for k in range(hospital_configuration["shifts_per_day"] * self.length_of_stay):
      if (k+1)%hospital_configuration["shifts_per_day"] == 0:
        if self.skill_level_required[k] > 0:
          self.skill_level_required[k] -= 1
          
class PatientEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Patient):
            # Exclude keys with None values
            return {k: v for k, v in obj.__dict__.items() if v is not None}
        return json.JSONEncoder.default(self, obj)
    
class Occupant:
  def __init__(self, occupant_id = None, room_id= None,gender = None, age_group = None, length_of_stay = None,
         workload_produced=None, skill_level_required=None):
    self.id = occupant_id
    self.gender = gender
    self.age_group = age_group
    self.length_of_stay = length_of_stay
    self.workload_produced = workload_produced or []
    self.skill_level_required = skill_level_required or []
    self.room_id = room_id
  
  def RandomOccupant(self,id,num_occupants,num_rooms,hospital_configuration):
    self.id = "a" + id_to_string(id,num_occupants-1)
    self.gender=random.choice(["B", "A"])
    Patient.RandomAge(self,hospital_configuration)
    self.length_of_stay = -1
    while self.length_of_stay <= 0:
      operation_day_was = random.randint(-13,-1)
      self.length_of_stay = operation_day_was + random.choices(list(hospital_configuration["lengths_of_stay"].keys()), weights=list(hospital_configuration["lengths_of_stay"].values()), k=1)[0]
    self.room_id = "r" + id_to_string(random.randint(0, num_rooms-1),num_rooms-1)
    self.workload_produced= [random.randint(hospital_configuration["workload_produced_minmax"]["night"][0], hospital_configuration["workload_produced_minmax"]["night"][1]) if (k+1)%hospital_configuration["shifts_per_day"] == 0 else random.randint(hospital_configuration["workload_produced_minmax"]["day"][0], hospital_configuration["workload_produced_minmax"]["day"][1]) for k in range(hospital_configuration["shifts_per_day"] * self.length_of_stay)]
    self.skill_level_required=[random.randint(0, hospital_configuration["skill_levels"] - 1) for _ in range(hospital_configuration["shifts_per_day"] * self.length_of_stay)]
    #I reduce the workload and the required skill at night
    for k in range(hospital_configuration["shifts_per_day"] * self.length_of_stay):
      if (k+1)%hospital_configuration["shifts_per_day"] == 0:
        if self.workload_produced[k] > 1:
          self.workload_produced[k] -= 1 
        if self.skill_level_required[k] > 0:
          self.skill_level_required[k] -= 1

class Surgeon:
  def __init__(self, surgeon_id = None, max_surgery_time = None, profile=None):
    self.id = surgeon_id
    self.max_surgery_time = max_surgery_time
    self.profile = profile

  def RandomSurgeon(self,surgeon_id,num_surgeons,hospital_days):
    self.id = "s" + id_to_string(surgeon_id,num_surgeons-1)
    self.max_surgery_time=[]
    self.profile= random.choice([[ 0.3, 0.3, 0.3, 0.1, 0, 0 ] , [ 0.1, 0.2, 0.2, 0.2, 0.2, 0.1 ], [ 0, 0.1, 0.3, 0.3, 0.3, 0.3 ]])
    while sum(self.max_surgery_time) == 0:
      weights_weekday = [random.uniform(0.0, 0.4),random.uniform(0.0, 0.4),random.uniform(0.4, 0.8),random.uniform(0.0, 0.2)]
      weights_weekend = [random.uniform(0.3, 1.0),random.uniform(0.0, 0.3),random.uniform(0.0, 0.2),random.uniform(0.0, 0.1)]
      weights_weekday = [x / sum(weights_weekday) for x in weights_weekday]
      weights_weekend = [x / sum(weights_weekend) for x in weights_weekend]
      for i in range(hospital_days):
        if i%5 == 0 or i%6 == 0:
          self.max_surgery_time.append(random.choices([0, 360, 480, 600],weights=weights_weekend)[0])
        else:
          self.max_surgery_time.append(random.choices([0, 360, 480, 600],weights=weights_weekday)[0])
    
  def to_dict(self):
    return {
        k: v for k, v in self.__dict__.items() if k != "profile"
    }

class OperatingTheater:
  def __init__(self, room_id = None, availability = None):
    self.id = room_id
    self.availability = availability

  def RandomOperatingTheater(self, i, num_operating_teathers,hospital_days):
    self.id= "t" + id_to_string(i,num_operating_teathers-1)
    weights_weekday = [random.uniform(0.0, 0.1),random.uniform(0.0, 0.2),random.uniform(0.4, 0.8),random.uniform(0.3, 0.6)]
    weights_weekend = [random.uniform(0.1, 0.5),random.uniform(0.0, 0.5),random.uniform(0.0, 0.6),random.uniform(0.0, 0.4)]
    weights_weekday = [x / sum(weights_weekday) for x in weights_weekday]
    weights_weekend = [x / sum(weights_weekend) for x in weights_weekend]
    self.availability=[]
    while sum(self.availability) == 0:
      for i in range(hospital_days):
        if i%5 == 0 or i%6 == 0:
          self.availability.append(random.choices([0, 480, 600, 720],weights=weights_weekend)[0])
        else:
          self.availability.append(random.choices([0, 480, 600, 720],weights=weights_weekday)[0])

class Nurse:
  def __init__(self, nurse_id = None, skill_level = None, working_shifts = None):
    self.id = nurse_id
    self.skill_level = skill_level
    self.working_shifts = working_shifts
  def RandomNurse(self, i, days, num_patients, hospital_configuration,remaining_shift_coverage):
    self.id= "n" + id_to_string(i,num_patients-1)

    #I generate the skill level
    self.skill_level=random.randint(0, hospital_configuration["skill_levels"] - 1)

    #I find the first uncovered shift
    first_uncovered = 0
    while remaining_shift_coverage[first_uncovered] == 0:
      first_uncovered += 1
    first_shift = -1
    while first_shift < 0 or first_shift >= hospital_configuration["shifts_per_day"] * days or remaining_shift_coverage[first_shift] == 0:
      first_shift = first_uncovered + int(random.lognormvariate(1.0, 0.2))-1
    numeric_working_shifts = [first_shift]
    #I generate the other shifts
    shift_list_completed = False
    last_shift = numeric_working_shifts[len(numeric_working_shifts)-1]
    next_shift = last_shift

    while(not shift_list_completed):
      next_shift = last_shift + int(random.lognormvariate(1.2, 0.3))
      while next_shift < numeric_working_shifts[len(numeric_working_shifts)-1] + 3:
        next_shift = last_shift + int(random.lognormvariate(1.2, 0.3))

      while next_shift < hospital_configuration["shifts_per_day"] * days and remaining_shift_coverage[next_shift] == 0:
        next_shift += 1
      
      if next_shift >= hospital_configuration["shifts_per_day"] * days:
        shift_list_completed = True
      else:
        numeric_working_shifts.append(next_shift)

      last_shift = next_shift

    #I convert the numeric shifts into actual shifts
    self.working_shifts = []
    for shift in numeric_working_shifts:
      day = int(shift/hospital_configuration["shifts_per_day"])
      shift_in_day = hospital_configuration["shift_types"][shift%hospital_configuration["shifts_per_day"]]
      #I generate the max load
      if self.skill_level==0:
        load = 10
      elif self.skill_level==1:
        load = 12
      else:
        prob_5 = random.uniform(0, 0.5)
        if random.uniform(0, 1) < prob_5:
          load = 5
        else:
          load = 15
      self.working_shifts.append({"day" : day, "shift" : shift_in_day, "max_load" : load})
    

class HospitalData:
  def __init__(self):
    self.days = -1
    self.patients = []
    self.occupants =[]
    self.surgeons = []
    self.operating_theaters = []
    self.rooms = []
    self.nurses = []
    self.configuration = {"shifts_per_day" : int, "skill_levels" : int, "shift_types" : [str], "age_groups" : dict, "scheduling_horizons" : [int], "lengths_of_stay" : dict, "room_size": list, "lognormariate_releasedate": list, "mandatory_ratio": int, "occupants_min_max" : list, "workload_produced_minmax" : dict}
    #default values
    self.configuration["skill_levels"] = 3
    self.configuration["shift_types"] = ["early", "late", "night"]
    self.configuration["shifts_per_day"] = len(self.configuration["shift_types"])
    self.configuration["age_groups"] = {"infant": [0,14], "adult": [15,65], "elderly": [66,100]}
    self.configuration["scheduling_horizons"] = [14, 21, 28]
    self.configuration["lengths_of_stay"] = {2 : 0.20, 3: 0.25, 4: 0.20, 5: 0.10, 6: 0.10, 7: 0.05, 8: 0.05, 9: 0.02, 10: 0.01, 11: 0.01, 12: 0.007, 13: 0.002, 14: 0.001}
    self.configuration["room_size"] = [2,3,4]
    self.configuration["lognormariate_releasedate"] = [1.0,1.6]
    self.configuration["mandatory_ratio"] = 0.7
    self.configuration["occupants_min_max"] = [0.2,0.6]
    self.configuration["workload_produced_minmax"] = {"day": [1,3], "night": [1,2]}

  def set_scheduling_horizon(self, days):
    self.days = days
  
  def get_shift_value(self,shift):
    shift_value = shift["day"]*3
    i = 0
    while self.configuration["shift_types"][i] != shift["shift"]:
      i+=1
    shift_value+=i
    return shift_value
  
  def set_age_groups(self,age_groups):

    age_group_configurations = {2 : {"infant": [0,18], "adult": [19,100]}, 3: {"infant": [0,14], "adult": [15,65], "elderly": [66,100]}, 4: {"infant": [0,14], "young": [15,29], "adult": [30,65], "elderly": [66,100]}, 5: {"baby": [0,12], "child": [13,22], "young": [23,40], "adult": [41,74], "elderly": [75,100]}}
    self.configuration["age_groups"] = age_group_configurations[age_groups]

  def to_dict(self):
    def exclude_none(patient_dict):
            return {k: v for k, v in patient_dict.items() if v is not None}
    return {
      "days": self.days,
      "skill_levels" : self.configuration["skill_levels"],
      "shift_types" : self.configuration["shift_types"],
      "age_groups" : [x for x in self.configuration["age_groups"].keys()],
      "occupants": [occupant.__dict__ for occupant in self.occupants],
      "patients": [exclude_none(patient.__dict__) for patient in self.patients if isinstance(patient, Patient)],
      "surgeons": [surgeon.to_dict() for surgeon in self.surgeons],
      "operating_theaters": [room.__dict__ for room in self.operating_theaters],
      "rooms": [room.__dict__ for room in self.rooms],
      "nurses": [nurse.__dict__ for nurse in self.nurses]
    }
  