#! /usr/bin/env python3
from ihgenerator import IHGenerator
import argparse
import os
import json
  
def main(args):
  """Execute the generator """ 
  generator = IHGenerator()
  if args.weeks is not None:
    generator.set_parameter("scheduling_horizon", args.weeks*7)
  if args.patients_density is not None:
    generator.set_parameter("patients_density", args.patients_density)
  elif args.patients is not None:
    if args.weeks is None:
      args.weeks = generator.random_weeks()
    generator.set_parameter("patients_density", args.patients/(args.weeks*7))
  if args.surgeons is not None:
    generator.set_parameter("surgeons", args.surgeons)
  if args.operating_theaters is not None:
    generator.set_parameter("operating_theaters", args.operating_theaters)
  if args.rooms is not None:
    generator.set_parameter("rooms", args.rooms)
  if args.skills is not None:
    generator.set_parameter("skills", args.skills)
  if args.age_groups is not None:
    generator.set_parameter("age_groups", args.age_groups)
  if args.mandatory_ratio is not None:
    generator.set_parameter("mandatory_ratio", args.mandatory_ratio)
  
  generated_data = generator.generate_random_data()
  
  if args.output is not None:
    if os.path.exists(args.output) and not args.overwrite:
      print("Output file already exists. Please remove it or change the name.")
      return

    with open(args.output, "w") as json_file:
      json.dump(generated_data, json_file, indent=2)
  else:
    print(json.dumps(generated_data, indent=2))

if __name__ == '__main__':
  parser = argparse.ArgumentParser(description='Integrated Healthcare Instance Generator')
  parser.add_argument('--output', '-o', required=False, type=str, help='output file, if not given prints instance on stdout')
  parser.add_argument('--weeks', '-w', required=False, type=int, help='scheduling horizon (weeks)')
  parser.add_argument('--patients', '-p', required=False, type=int, help='number of patients')
  parser.add_argument('--patients_density', '-pd', required=False, type=float, help='patients density: daily mean number of admissions')
  parser.add_argument('--mandatory_ratio', '-m', required=False, type=float, help='expected ratio of mandatory patients on total patients, in case of unvailabilities of surgeons or op.theaters, the actual mandatory ratio might be smaller. Default is 0.7')
  parser.add_argument('--surgeons', '-s', required=False, type=int, help='number of surgeons')
  parser.add_argument('--operating_theaters', '-t', required=False, type=int, help='number of operating theaters')
  parser.add_argument('--rooms', '-r', required=False, type=int, help='number of rooms')
  parser.add_argument('--skills', '-k', required=False, type=int, help='number of skills')
  parser.add_argument('--age_groups', '-a', required=False, type=int, help='number of age groups')
  parser.add_argument('--overwrite', '-ow', required=False, action='store_true', help='overwrite the output file if it exists')
  
  args = parser.parse_args()
  if(args.patients is not None and args.patients_density is not None):
    parser.error("Cannot specify both patients and patients_density")
  
  main(args)
